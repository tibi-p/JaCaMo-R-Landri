public class Bet
{
	double sum;
	String type;
	Object[] betValues;
}
