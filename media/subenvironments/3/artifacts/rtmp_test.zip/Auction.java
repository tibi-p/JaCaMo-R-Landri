import java.util.Random;

import org.aria.rlandri.generic.artifacts.RealTimeMultiPlayerCoordinator;
import org.aria.rlandri.generic.artifacts.annotation.GAME_OPERATION;

import cartago.CartagoException;
import cartago.ObsProperty;
import cartago.OpFeedbackParam;

public class Auction extends RealTimeMultiPlayerCoordinator {
	String object = "Hotel Cismigiu", lastBidder;
	int currentBid;
	boolean timeUp, started;
	
	@Override
	protected void updateRank() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void updateCurrency() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void saveState() {
		// TODO Auto-generated method stub

	}
	@Override
	protected void init() throws CartagoException {
		super.init();
		currentBid = 1;
		timeUp = false;
		lastBidder = "";
	}

	@GAME_OPERATION(validator = "derp")
	void startAuction() throws InterruptedException {
		started = true;
		signal("bidEvent");
	}

	@GAME_OPERATION(validator = "derp")
	void stopAuction(){
		timeUp = true;
		System.out.println(agents.get(lastBidder).getAgentName() + " is winrar");
		signal(agents.get(lastBidder), "you_are_a_winrar");
	}
	
	@GAME_OPERATION(validator = "priceValid")
	void bid(int price) {
		currentBid = price;
		signal("bidEvent");
		lastBidder = getOpUserName();
		
		System.out.println(lastBidder + " bidded " + price);
	}

	void priceValid(int price) {
		if(!started)
			failed("not_started_yet");
		if (timeUp)
			failed("time_is_up");
		if(getOpUserName().equals(lastBidder))
			failed("already_bidded");
		if (price <= currentBid)
			failed("bid_too_low");
	}

	@GAME_OPERATION(validator = "herp")
	void poll(OpFeedbackParam<Integer> price) {
		price.set(currentBid);
	}
	
	void derp(){}
	void herp(OpFeedbackParam<Integer> adfslkrg){}
	
	@GAME_OPERATION(validator = "herp")
	void getRandomBudget(OpFeedbackParam<Integer> budget){
		budget.set(new Random().nextInt(100));
	}
}
