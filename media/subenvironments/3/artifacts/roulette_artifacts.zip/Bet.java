public class Bet
{
	double sum;
	String type;
	int value;

}
