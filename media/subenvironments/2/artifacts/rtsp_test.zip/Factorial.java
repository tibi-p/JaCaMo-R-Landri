import org.aria.rlandri.generic.artifacts.RealTimeSinglePlayerCoordinator;
import org.aria.rlandri.generic.artifacts.annotation.GAME_OPERATION;

public class Factorial extends RealTimeSinglePlayerCoordinator {

	private boolean started = false;

	@GAME_OPERATION(validator = "foreverAlone")
	void start() {
		if (!started) {
			defineObsProperty("goal", 5);
			started = true;
		}
	}

	@GAME_OPERATION(validator = "catzelush")
	public void derp(int result) {
		System.out.println("good job, brah: " + result);
	}

	void catzelush(int result) {
		if (result != 120)
			failed("nu te-am avut in hotel cismigiu");
	}

	void foreverAlone() {

	}

}
