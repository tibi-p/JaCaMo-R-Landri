import org.aria.rlandri.generic.artifacts.RealTimeSinglePlayerCoordinator;
import org.aria.rlandri.generic.artifacts.annotation.GAME_OPERATION;

public class Factorial extends RealTimeSinglePlayerCoordinator {

	@GAME_OPERATION(validator = "asdf")
	void start() {
		defineObsProperty("goal", 5);
	}

	@GAME_OPERATION(validator = "catzelush")
	public void derp(int result) {
		System.out.println("good job, brah");
	}

	void catzelush(int result) {
		if (result != 600)
			failed("nu te-am avut in hotel cismigiu");
	}

	void asdf() {

	}
}
