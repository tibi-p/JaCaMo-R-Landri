package artifacts;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import cartago.Artifact;
import cartago.OPERATION;

/**
 * @author Mihai
 *
 */
public class LoggerArtifact extends Artifact {
	
	
	@OPERATION
	public void logInfo(String line){
		logger("[INFO]" + line);
	}
	
	@OPERATION
	public void logWarning(String line){
		logger("[WARNING]" + line);
	}
	
	@OPERATION
	public void logError(String line){
		logger("[ERROR]" + line);
	}
	
	@OPERATION
	public void logCritical(String line){
		logger("[CRITICAL]" + line);
	}
	
	private void logger(String line){
		/*
		 * @agent: the jason name of the agent
		 * @agentBaseName: the 'root' name of the agent
		 * 					e.g.: "Rambo-4# -> 'Rambo'
		 */
		String agent = getOpUserName(), agentBaseName;

		if(agent.endsWith("#")){ //Check if agent is a clone instance
			agentBaseName = agent.substring(0, agent.lastIndexOf('-')); //extract root
			agent = agent.substring(0, agent.lastIndexOf('#')); //we don't need the "#" anymore
		}
		else{
			agentBaseName = agent;
		}
		
		File agDir = new File ("./media/agents/" + agentBaseName);
		if(!agDir.exists()) agDir.mkdir();

		Calendar date = Calendar.getInstance();
		DateFormat day = new SimpleDateFormat("dd/MM/yy"),
				hour = new SimpleDateFormat("HH:mm:ss");
		
		File agLog = new File(day.toString() + ".log"); //the log for that day
		if(!agLog.exists()){ //make sure file exists
			try {
				agLog.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
		}
		try{
			
		PrintWriter pw = new PrintWriter(agLog);
		pw.println("[" + hour.toString() + "]" + "[" + agent + "]" + line);
		pw.close();
		
		}catch(FileNotFoundException e){
			//Impossible to not find file, because we made sure it exists
		}
	}
}
